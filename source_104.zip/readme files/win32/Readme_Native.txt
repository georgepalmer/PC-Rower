PC-Rower 1.04
-------------

Install:
To install copy the PC-Rower folder to the destination of your choice.
I recommend you create a data directory within the PC-Rower folder to save your workouts in


Starting:
Double click the PC-Rower.exe file.


Run time:
Make sure the PM2+ is plugged in and your serial port setup to 9600 bits per second, 8 databits, 1 stopbit, and no parity (this is the standard setup so you should be ok).

In the options dialog the 'Retrieve full stroke data' when switched off will only retrieve the time and distance of each boat. This speeds up the software which is useful when there are lots of PM2+ units plugged in but means logging would not have any data for stroke split, power etc.

The rest of the program options should be intuitive.


Problems/Bugs:
Please submit to bugs@rowtheboat.com